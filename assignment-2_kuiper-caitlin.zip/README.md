# Assignment 2
[Assignment Link](https://www.caitlinkuiper.com/advweb2_assignment2_kuiper_caitlin/)
## Resources
I did not use any resources outside of the lectures and my notes on this
assignment.

### Comments
How does BEM work for paragraphs and navigation links?
